#install.packages("tidyr")
##This file only convert's the given data into an adjacency matrix
library(tidyr)
library(plyr)
advice <- read.csv("Advice.csv",header = FALSE)
advice<- separate(advice,V1, into = c("delete","nodes_out","nodes_in","Link"))
advice["nodes_in"] <- as.numeric(advice$nodes_in)
advice["nodes_out"] <- as.numeric(advice$nodes_out)
advice["Link"] <- as.numeric(advice$Link)
advice<- advice[,-1]
advice<- spread(advice,nodes_in,Link)
seq <- seq(1,77,1)
new.row <- data.frame(nodes_out=setdiff(seq,advice$nodes_out),stringsAsFactors=F)
advice <- rbind.fill(advice, new.row)
advice<- advice[order(advice$nodes_out),]
rownames(advice) <- advice$nodes_out
advice<- advice[,-1]
advice[is.na(advice)]<-0
advice[advice>1]<-1
write.csv(advice,"data_cleaned_advice.csv")



