#install.packages("rgl")

library(igraph)

library(tidyr)
library(cluster)

## Reading the data into igraph object and plotting the graph
advice <- read.csv("data_cleaned_advice.csv")
advice <- advice[,-1]
advice.m <- as.matrix(advice)
advice.g <- graph.adjacency(advice.m,mode = "directed")
#rglplot(advice.g)  #To Plot 3D graph - Not required
plot(advice.g,vertex.size=4,edge.arrow.size=0.1,margin=-0.5)


###Assigning the attributes to the advice graph

location <- scan("location.txt")
position <- scan("position.txt")
tenure <- scan("tenure.txt")

V(advice.g)$location <- location
V(advice.g)$position <- position
V(advice.g)$tenure <- tenure

## Color coded by Position
V(advice.g)$color <- V(advice.g)$position

plot(advice.g,vertex.size=4,edge.arrow.size=0.1,margin=-0.5)

## In the first skim through the network, we see that 68 and 15, who is the global
## head of the organisation and a Project Manager is placed at the center of the network and has a 
## lot of influence in the network. 15 might be up for promotion.


##Color coded by Location

V(advice.g)[V(advice.g)$location==1]$color <- "red"  #Paris
V(advice.g)[V(advice.g)$location==2]$color <- "white"  #FrankFurt
V(advice.g)[V(advice.g)$location==3]$color <- "yellow"  #Warsaw
V(advice.g)[V(advice.g)$location==4]$color <- "orange"   #Geneva

plot(advice.g,vertex.size=4,edge.arrow.size=0.1,margin=-0.5)

##We see 4 separate cluster's very clearly when color coded by location. Again X68,15,74,49 show a lot of promise
##We will show some more interesting stuff later regarding intercity distances

##COlor coded by tenure
V(advice.g)$color <- V(advice.g)$tenure

plot(advice.g,vertex.size=4,edge.arrow.size=0.1,margin=-0.5)
## At the first glance we can see that the 3rd group of tenure lie in more 


### Working numerically to find out the influencers/prominent nodes 
##Checking vertex attributes
vertex.attributes(advice.g)

##Checking the degree's of the network
out_degree <- data.frame(degree(advice.g,mode="out"))
in_degree <- data.frame(degree(advice.g,mode="in"))
degree <- data.frame(degree(advice.g))

##Sorting the network by the indegree and outdegree
out_degree[,2] <- rownames(out_degree) 
out_degree <- out_degree[order(out_degree$degree.advice.g..mode....out..),]
write.csv(out_degree,"All_Prominent.csv")
write.csv(head(out_degree),"Top_Prominent.csv")

in_degree[,2]<-rownames(in_degree)
in_degree <- in_degree[order(in_degree$degree.advice.g..mode....in..),]
write.csv(out_degree,"All_Influencers.csv")
write.csv(head(in_degree),"Top_Influencers.csv")

degree[,2] <- rownames(degree)
degree <- degree[order(-degree$degree.advice.g.),]

##Checking for betweenness

between <- data.frame(betweenness(advice.g))
between[,2] <- rownames(between)
between <- between[order(-between$betweenness.advice.g.),]
write.csv(between,"All_Brokers.csv")
write.csv(head(between),"Top_Brokers.csv")

central <- merge(in_degree,between,by="V2")

#Checking for closeness

closeness <- data.frame(closeness(advice.g))
closeness[,2] <- rownames(closeness)
closeness<- closeness[order(-closeness$closeness.advice.g.),]


central <- merge(central,closeness,by="V2")
write.csv(central,"The_centrality_table.csv")


head(central[order(-central$degree.advice.g..mode....in..),])


##The Centrality Report
scalef <- function(x){(x-min(x))/(max(x)-min(x))}
y <- central$V2
x <- central[,-1]
x <- scalef(x)
x$closeness.advice.g.<- x$closeness.advice.g.*10000
regions <- c("Degree","Betweeness","Closeness")
colors <- c("green","orange","red")
barplot(t(x),names.arg = y, col=colors,beside=F, main="Centrality Report",las=0.5)
legend("topleft", regions, cex = 0.5, fill = colors)

###This graph gives us all the interesting stuff required. Match it with the corelation matrix

##Subgraphing the network by position

local_dept_manager <- subgraph(advice.g,V(advice.g)$position=="2")
V(local_dept_manager)[V(local_dept_manager)$location==1]$color <- "red"  #Paris
V(local_dept_manager)[V(local_dept_manager)$location==2]$color <- "white"  #FrankFurt
V(local_dept_manager)[V(local_dept_manager)$location==3]$color <- "yellow"  #Warsaw
V(local_dept_manager)[V(local_dept_manager)$location==4]$color <- "orange"   #Geneva
plot(local_dept_manager) 
position <- c("Paris","Frankfurt","Warsaw","Geneva")
colors <- c("Red","White","Yellow","Orange")
legend("left", position, cex = 0.5, fill = colors)

##Here are some problem's within the organisation, X51 (Warsaw) is not interacting with the 
##city head's in Paris(X13) and Frankfurt(X29). Also looks like Geneva is need of a city head. 


project_leader <- subgraph(advice.g,V(advice.g)$position=="3")
V(project_leader)[V(project_leader)$location==1]$color <- "red"  #Paris
V(project_leader)[V(project_leader)$location==2]$color <- "white"  #FrankFurt
V(project_leader)[V(project_leader)$location==3]$color <- "yellow"  #Warsaw
V(project_leader)[V(project_leader)$location==4]$color <- "orange"   #Geneva
sort(betweenness(project_leader))
plot(project_leader,margin =-0.15,edge.arrow.size=.1)
position <- c("Paris","Frankfurt","Warsaw","Geneva")
colors <- c("Red","White","Yellow","Orange")
legend("topleft", position, cex = 0.5, fill = colors)

##Looking at this X54 seemes to be a reasonable replacement to X51. Also X71/x64 looks like a reasonable option to become city head in Geneva.
##The above shows that X15 has an extremly high betweeness, indicating that it is acting as a link for the team's across the globe.
##This person has only 3 degrees less than X13 who is the current city head but much higer betweeness and closeness and can becomet the city head.

sub <- c("X54","X15","X29","X71")
promotion_test <- induced.subgraph(advice.g,vids=sub)
V(promotion_test)$color <- V(promotion_test)$position
plot(promotion_test)

##After implementing our suggestion we form an extremely strong network of city heads.
##Checking their connectivity with the Global Head X68

sub <- c("X54","X15","X29","X71","X68")
promotion_test <- induced.subgraph(advice.g,vids=sub)
V(promotion_test)$color <- V(promotion_test)$position
plot(promotion_test)

##Great, all of them are connected and this forms an extremely strong network at the top management


##FINAL SUGGESTIONS : - PROMOTE 54 TO CITY HEAD. REMOVE 51/ TRANSFER
##FINAL SUGGESTIONS : - PROMOTE 15 TO CITY HEAD. REMOVE 13/ TRANSFER

##CHECK SKILL AWARENESS DATASET AND CONFIRM THIS

##Subgraphing the network by locationa and position
paris <- subgraph(advice.g,V(advice.g)$location==1)
#paris <- delete.vertices(paris,'X13')
#V(paris)$position[14] <-2
V(paris)[V(paris)$position==1]$color <- "red"  #Paris
V(paris)[V(paris)$position==2]$color <- "white"  #FrankFurt
V(paris)[V(paris)$position==3]$color <- "yellow"  #Warsaw
V(paris)[V(paris)$position==4]$color <- "orange"   #Geneva
plot(paris,margin=-.25,edge.arrow.size=0.1)
sort(degree(paris,mode="in"))
edge_density(paris)


##Paris with Frankfurt
paris_f <- subgraph(advice.g,V(advice.g)$location==1 | V(advice.g)$location==2)
paris_f <- subgraph(paris_f,V(paris_f)$position==4)
V(paris_f)[V(paris_f)$location==1]$color <- "red"  #Paris
V(paris_f)[V(paris_f)$location==2]$color <- "white"  #FrankFurt
plot(paris_f,margin=-.33,edge.arrow.size=0.1)
position <- c("Paris","Frankfurt")
colors <- c("Red","White")
legend("left", position, cex = 0.5, fill = colors)
edge_density(paris_f)
sort(betweenness(paris_f))

##Paris with warsaw
paris_w <- subgraph(advice.g,V(advice.g)$location==1 | V(advice.g)$location==3)
paris_w <- subgraph(paris_f,V(paris_f)$position==4)
V(paris_w)[V(paris_w)$location==1]$color <- "red"  #Paris
V(paris_w)[V(paris_w)$location==3]$color <- "Yellow"  #Warsaw
plot(paris_w,margin=-.33,edge.arrow.size=0.1)
position <- c("Paris","Warsaw")
colors <- c("Red","Yellow")
legend("left", position, cex = 0.5, fill = colors)
edge_density(paris_w)
sort(betweenness(paris_w))

##Paris with Genev
paris_G <- subgraph(advice.g,V(advice.g)$location==1 | V(advice.g)$location==4)
paris_G <- subgraph(paris_G,V(paris_G)$position==4)
V(paris_G)[V(paris_G)$location==1]$color <- "red"  #Paris
V(paris_G)[V(paris_G)$location==4]$color <- "Yellow"  #Warsaw
plot(paris_G,margin=-.33,edge.arrow.size=0.1)
edge_density(paris_G)
sort(betweenness(paris_G))

##Frankfurt
frankfurt <- subgraph(advice.g,V(advice.g)$location==2)
V(frankfurt)$color <- V(frankfurt)$position
plot(frankfurt,margin=-.5,edge.arrow.size =.1)
top_influencers_frankfurt <- head(sort(degree(frankfurt),decreasing=TRUE))
edge_density(frankfurt)

## The center at frankfurt is extrmely interesting, it's a very horizontal based heirarchy

##Frankfurt and warsaw
f_w<- subgraph(advice.g,V(advice.g)$location==2 | V(advice.g)$location==3)
f_w <- subgraph(f_w,V(f_w)$position==4)
V(f_w)[V(f_w)$location==2]$color <- "White"  #Frankfurt
V(f_w)[V(f_w)$location==3]$color <- "lightblue"  #Warsaw
plot(f_w,margin=-.33,edge.arrow.size=0.1)
edge_density(f_w)
sort(betweenness(f_w))

##Frankfurt and geneva
f_g<- subgraph(advice.g,V(advice.g)$location==2 | V(advice.g)$location==4)
f_g <- subgraph(f_g,V(f_g)$position==4)
V(f_g)[V(f_g)$location==2]$color <- "White"  #Frankfurt
V(f_g)[V(f_g)$location==4]$color <- "lightblue"  #Geneva
plot(f_g,margin=-.33,edge.arrow.size=0.1)
edge_density(f_g)
sort(betweenness(f_g))

##Warsaw and Geneva
w_g<- subgraph(advice.g,V(advice.g)$location==3 | V(advice.g)$location==4)
w_g <- subgraph(w_g,V(w_g)$position==4)
V(w_g)[V(w_g)$location==3]$color <- "Yellow"  #Warsaw
V(w_g)[V(w_g)$location==4]$color <- "lightblue"  #Geneva
plot(w_g,margin=-.33,edge.arrow.size=0.1)
edge_density(w_g)
sort(betweenness(w_g))

###WARSAW
warsaw <- subgraph(advice.g,V(advice.g)$location==3)
V(warsaw)$color <- V(warsaw)$position
sort(degree(warsaw),decreasing=TRUE)
plot(warsaw,margin=-.37)
edge_density(warsaw)



##GENEVA
geneva <- subgraph(advice.g,V(advice.g)$location==4)
V(geneva)$color <- V(geneva)$position
sort(degree(geneva,mode="in"),decreasing=TRUE)
plot(geneva,margin=-.05,edge.arrow.size=0.1)
position <- c("Global Head","Project Leads","Researchers")
legend("left", position, cex = 0.5, fill = colors)
edge_density(geneva)
betweenness(geneva)


##Checking Connections of 68
subv <- c('X62','X68','X73','X75','X71','X77')
graph68 <- induced.subgraph(geneva,vids=subv)
plot(graph68)
###This graph shows that the guy 73 has a lower number of in-degree's but important people in the organisation consult him for advice.
###Indicating that he is one of the most influential person in the network. But due to his lack of connectivity with other's, 71 is still
##better option for city head

barplot(degree(advice.g))
barplot(degree(geneva))
barplot(degree(warsaw))
barplot(degree(frankfurt))
barplot(degree(paris))

library(igraph)
library(sna)

paris.m <- as.matrix(get.adjacency(paris_w))
eq <- equiv.clust(paris.m)
plot(eq)
#b <- blockmodel(geneva.m,eq,k=2)
#b <- blockmodel(geneva.m,eq,k=3)
#b <- blockmodel(geneva.m,eq,k=4)
b <- blockmodel(paris.m,eq,k=12,mode="graphs")
#b <- blockmodel(geneva.m,eq,k=7)

plot(b)
