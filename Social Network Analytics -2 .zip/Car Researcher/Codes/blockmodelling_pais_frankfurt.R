library(sna)


geneva.m <- as.matrix(get.adjacency(paris_f))
geneva.m
eq <- equiv.clust(geneva.m)
plot(eq)
#b <- blockmodel(geneva.m,eq,k=2)
#b <- blockmodel(geneva.m,eq,k=3)
#b <- blockmodel(geneva.m,eq,k=4)
b <- blockmodel(geneva.m,eq,k=12,mode="graphs")
#b <- blockmodel(geneva.m,eq,k=7)

plot(b)
title(xlab  ="BlockModel for Paris and Frankfurt Researchers with 12 clusters")

