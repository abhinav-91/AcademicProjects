library(sna)


geneva.m <- as.matrix(get.adjacency(paris_w))
geneva.m
eq <- equiv.clust(geneva.m)
plot(eq)
#b <- blockmodel(geneva.m,eq,k=2)
#b <- blockmodel(geneva.m,eq,k=3)
#b <- blockmodel(geneva.m,eq,k=4)
b <- blockmodel(geneva.m,eq,k=12,mode="graphs")
#b <- blockmodel(geneva.m,eq,k=7)

plot(b)
title(xlab  ="BlockModel for Paris and Frankfurt Researchers with 12 clusters")

vertex.attributes(geneva)

##This supports our first recommendation . 64 and 71 come to be structurally equivalent.
##But wi

# obtain the overall network density
den <- edge_density(geneva)

# Prepare to obtain the image matrix
bimage <- b$block.model
bimage
# Blocks with density less than overall network
# density are reduced to zero
bimage[bimage < den] <- 0   
bimage
bimage[bimage > den] <- 1
bimage
bimage[is.nan(bimage)] <- 1
bimage



# View the plot
gplot(bimage, diag=TRUE, 
      edge.lwd=bimage*5, 
      label=colnames(bimage),
      vertex.cex=sqrt(table(b$block.membership))*2,
      gmode="digraph", vertex.sides=50,
      vertex.col=gray(1-diag(bimage)/2))

t <- as.data.frame(sort(degree(advice.g)))
t["name"] <- rownames(t)
x <- as.data.frame(vertex.attributes(advice.g))
z <- merge(t,x,by="name")

barplot(z$`sort(degree(advice.g))`,names.arg = z$name)
