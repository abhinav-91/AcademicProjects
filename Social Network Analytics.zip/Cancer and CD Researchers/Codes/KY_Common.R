
###Finding people common to 2015 and 2016
common <- intersect(rownames(kentucky.data),rownames(kentucky.data.16))
common
kentucky.data <- kentucky.data[rownames(kentucky.data) %in% common, ]
kentucky.data <- kentucky.data[,colnames(kentucky.data) %in% common ]
kentucky.data.16 <- kentucky.data.16[rownames(kentucky.data.16) %in% common, ]
kentucky.data.16 <- kentucky.data.16[,colnames(kentucky.data.16) %in% common ]


kentucky.info.R <- kentucky.info.R[, colnames(kentucky.info.R) %in% common]
kentucky.info.R <- kentucky.info.R[rownames(kentucky.info.R) %in% common,]

kentucky.info.R.16 <- kentucky.info.R.16[, colnames(kentucky.info.R.16) %in% common]
kentucky.info.R.16 <- kentucky.info.R.16[rownames(kentucky.info.R.16) %in% common,]

kentucky.info.S.16 <- kentucky.info.S.16[, colnames(kentucky.info.S.16) %in% common]
kentucky.info.S.16 <- kentucky.info.S.16[rownames(kentucky.info.S.16) %in% common,]

kentucky.info.S <- kentucky.info.S[, colnames(kentucky.info.S) %in% common]
kentucky.info.S <- kentucky.info.S[rownames(kentucky.info.S) %in% common,]

attributes.data <- attributes.data[rownames(attributes.data) %in% common, ]

attributes.data.16 <- attributes.data[rownames(attributes.data.16) %in% common,]

