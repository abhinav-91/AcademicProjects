##2015 data

#Reading the csv file
sd.data <- read.csv("Roundtables_SNA_2015_100716_SD How do you know.csv",header=TRUE)

#Converting the NA values into zero
sd.data[is.na(sd.data)] <- 0

#Convert the first column into rownames
rownames(sd.data) <- sd.data[,1]

#Drop the first column
sd.data <- sd.data[-c(1)]

#Convert anything greater than 1 into 1
sd.data[sd.data > 1] <- 1

###Reading the common
attributes.data <- read.csv("Roundtables_SNA_2015_101116_SD Attributes.csv")

rownames(attributes.data )<- attributes.data[,1]

###Reading the info file

sd.info.R <- read.csv("Roundtables_SNA_2015_100716_SD Receive info.csv",header=T)
sd.info.S <- read.csv("Roundtables_SNA_2015_100716_SD Send info.csv",header=T)


rownames(sd.info.R) <- sd.info.R[,1]
sd.info.R <- sd.info.R[,-1]
sd.info.R[sd.info.R > 1] <- 1
sd.info.R[is.na(sd.info.R)] <- 0

rownames(sd.info.S) <- sd.info.S[,1]
sd.info.S <- sd.info.S[,-1]
sd.info.S[sd.info.S > 1] <- 1
sd.info.S[is.na(sd.info.S)] <- 0


##2016 data

#Reading the csv file
sd.data.16 <- read.csv("Roundtables_SNA_2016_081916_SD how do you know.csv",header=TRUE)

#Converting the NA values into zero
sd.data.16[is.na(sd.data.16)] <- 0

#Convert the first column into rownames
rownames(sd.data.16) <- sd.data.16[,1]

#Drop the first column
sd.data.16 <- sd.data.16[-c(1)]

#Convert anything greater than 1 into 1
sd.data.16[sd.data.16 > 1] <- 1

###Reading the common
attributes.data.16 <- read.csv("Roundtables_SNA_2016_081916_SD Attributes.csv")

rownames(attributes.data.16 )<- attributes.data.16[,1]
###Reading the info file

sd.info.R.16 <- read.csv("Roundtables_SNA_2016_081916_SD Receive info.csv",header=T)
sd.info.S.16 <- read.csv("Roundtables_SNA_2016_081916_SD Send info.csv",header=T)


rownames(sd.info.R.16) <- sd.info.R.16[,1]
sd.info.R.16 <- sd.info.R.16[,-1]
sd.info.R.16[sd.info.R.16 > 1] <- 1
sd.info.R.16[is.na(sd.info.R.16)] <- 0

rownames(sd.info.S.16) <- sd.info.S.16[,1]
sd.info.S.16 <- sd.info.S.16[,-1]
sd.info.S.16[sd.info.S.16 > 1] <- 1
sd.info.S.16[is.na(sd.info.S.16)] <- 0

