
###Finding people common to 2015 and 2016
common <- intersect(rownames(sd.data),rownames(sd.data.16))
common
sd.data <- sd.data[rownames(sd.data) %in% common, ]
sd.data <- sd.data[,colnames(sd.data) %in% common ]
sd.data.16 <- sd.data.16[rownames(sd.data.16) %in% common, ]
sd.data.16 <- sd.data.16[,colnames(sd.data.16) %in% common ]


sd.info.R <- sd.info.R[, colnames(sd.info.R) %in% common]
sd.info.R <- sd.info.R[rownames(sd.info.R) %in% common,]

sd.info.R.16 <- sd.info.R.16[, colnames(sd.info.R.16) %in% common]
sd.info.R.16 <- sd.info.R.16[rownames(sd.info.R.16) %in% common,]

sd.info.S.16 <- sd.info.S.16[, colnames(sd.info.S.16) %in% common]
sd.info.S.16 <- sd.info.S.16[rownames(sd.info.S.16) %in% common,]

sd.info.S <- sd.info.S[, colnames(sd.info.S) %in% common]
sd.info.S <- sd.info.S[rownames(sd.info.S) %in% common,]

attributes.data <- attributes.data[rownames(attributes.data) %in% common, ]

attributes.data.16 <- attributes.data[rownames(attributes.data.16) %in% common,]

