library(igraph)

#Creating the i-graph object and then plotting it
adj <- as.matrix(kentucky.data)

g1=graph.adjacency(adj,mode="directed",weighted=NULL,diag=FALSE)

plot(g1,margin=-0.4,edge.arrow.size=0.1)

adj <- as.matrix(kentucky.info.R)

g5=graph.adjacency(adj,mode="directed",weighted=NULL,diag=F)

adj <- as.matrix(kentucky.info.S)

g6=graph.adjacency(adj,mode="directed",weighted=NULL,diag=F)

edge_density(g1)

##Adding the attribute of C Researcher 
vertex_attr(g1)

rownames(attributes.data) <- attributes.data$PersonID

attributes.data <- attributes.data[,-1]

attributes.data[is.na(attributes.data)] <-0

attributes.data[attributes.data > 2] <- 0

att.data.c <- attributes.data$CancerCD

V(g1)$TopicC <- att.data.c
V(g5)$TopicC <- att.data.c
V(g6)$TopicC <- att.data.c


vertex.attributes(g1)

## Color coding the graph
V(g1)$color=V(g1)$TopicC
V(g5)$color=V(g5)$TopicC
V(g6)$color=V(g6)$TopicC
V(g1)$color=gsub(1,"red",V(g1)$color) #Cancer will be red
V(g1)$color=gsub(0,"blue",V(g1)$color) #Dont will be blue
V(g1)$color=gsub(2,"Yellow",V(g1)$color) #CD will be Yellow
plot.igraph(g1,margin=-0.3,edge.arrow.size=0.1)
title(main="kentucky- 2015")
edge_density(g1)
V(g1)$TopicC
vertex.attributes(g1)
####Subgraph
kentucky <- subgraph(g1,V(g1)$TopicC =="1" | V(g1)$TopicC =="2")
plot(kentucky,edge.arrow.size=0.1,margin=-0.3)
title(main = "Cancer & CD Researcher")


kentucky.s <- subgraph(g5,V(g5)$TopicC == 1 | V(g5)$TopicC == 2)
plot(kentucky.s)
kentucky.r <- subgraph(g6,V(g5)$TopicC == 1 | V(g5)$TopicC == 2)


##Creating the block model
library(sna)
g1 <- as.matrix(get.adjacency(kentucky))
g7 <- as.matrix(get.adjacency(kentucky.s))
g8 <- as.matrix(get.adjacency(kentucky.r))

eq <- equiv.clust(list(g1,g7,g8))
plot(eq)

b <- blockmodel(g1,eq,k=2,mode="graphs")
plot(b)


#######################################################################
#######################################################################
#######################################################################
#######################################################################



#Creating the i-graph object and then plotting it
adj <- as.matrix(kentucky.data.16)

g3=graph.adjacency(adj,mode="directed",weighted=NULL,diag=FALSE)

plot(g3,margin=-0.4,edge.arrow.size=0.1)

adj <- as.matrix(kentucky.info.R.16)

g5=graph.adjacency(adj,mode="directed",weighted=NULL,diag=F)

adj <- as.matrix(kentucky.info.S.16)

g6=graph.adjacency(adj,mode="directed",weighted=NULL,diag=F)


##Adding the attribute of C Researcher 
vertex_attr(g3)


rownames(attributes.data.16) <- attributes.data.16$PersonID

attributes.data.16 <- attributes.data.16[,-1]

attributes.data.16[is.na(attributes.data.16)] <-0

attributes.data.16[attributes.data.16 > 2] <- 0

att.data.c <- attributes.data.16$CancerCD

V(g3)$TopicC <- att.data.c
V(g5)$TopicC <- att.data.c
V(g6)$TopicC <- att.data.c

vertex.attributes(g3)
vertex.attributes(g3)
## Color coding the graph
V(g3)$color=V(g3)$TopicC
V(g5)$color=V(g5)$TopicC
V(g6)$color=V(g6)$TopicC
#V(g3)$color=gsub(1,"red",V(g1)$color) #Cancer will be red
#V(g3)$color=gsub(0,"blue",V(g1)$color) #Dont will be blue
#V(g3)$color=gsub(2,"Yellow",V(g1)$color) #CD will be Yellow
plot.igraph(g3,margin=-0.3,edge.arrow.size=0.1)
title(main="kentucky 2016")
edge_density(g3)

vertex.attributes(g3)
V(g3)$TopicC
####Subgraph
kentucky.16 <- subgraph(g3,V(g3)$TopicC == 1 | V(g3)$TopicC == 2)
plot(kentucky.16,edge.arrow.size=0.1,margin=-0.3)
title(main="kentucky - Cancer & CD Researcher - 2016")

kentucky.16.s <- subgraph(g5,V(g5)$TopicC == 1 | V(g5)$TopicC == 2)
plot(kentucky.16.s)
kentucky.16.r <- subgraph(g6,V(g5)$TopicC == 1 | V(g5)$TopicC == 2)


##Creating the block model

library(sna)
g4 <- as.matrix(get.adjacency(kentucky.16))
g7 <- as.matrix(get.adjacency(kentucky.16.s))
g8 <- as.matrix(get.adjacency(kentucky.16.r))
eq <- equiv.clust(list(g4,g7,g8))
plot(eq)

b1 <- blockmodel(g4,eq,k=2,mode="graphs")
plot(b1)


