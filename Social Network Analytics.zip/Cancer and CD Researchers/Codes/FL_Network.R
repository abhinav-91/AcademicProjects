##2015 data

#Reading the csv file
florida.data <- read.csv("Roundtables_SNA_2015_100716_FL how do you know.csv",header=TRUE)

#Converting the NA values into zero
florida.data[is.na(florida.data)] <- 0

#Convert the first column into rownames
rownames(florida.data) <- florida.data$Person.ID

#Drop the first column
florida.data <- florida.data[-c(1)]

#Convert anything greater than 1 into 1
florida.data[florida.data > 1] <- 1


library(igraph)

#Creating the i-graph object and then plotting it
adj <- as.matrix(florida.data)

g1=graph.adjacency(adj,mode="directed",weighted=NULL,diag=FALSE)

plot(g1,margin=-0.4,edge.arrow.size=0.1)


##Adding the attribute of C Researcher 
vertex_attr(g1)

attributes.data <- read.csv("Roundtables_SNA_2015_101116_FL Attributess.csv")

rownames(attributes.data) <- attributes.data$PersonID

attributes.data <- attributes.data[,-1]

attributes.data[is.na(attributes.data)] <-0

attributes.data[attributes.data > 2] <- 0

att.data.c <- attributes.data$CancerCD

V(g1)$TopicC <- att.data.c

vertex.attributes(g1)

## Color coding the graph
V(g1)$color=V(g1)$TopicC
V(g1)$color=gsub(1,"red",V(g1)$color) #Cancer will be red
V(g1)$color=gsub(0,"blue",V(g1)$color) #Dont will be blue
V(g1)$color=gsub(2,"Yellow",V(g1)$color) #CD will be Yellow
plot.igraph(g1,margin=-0.3,edge.arrow.size=0.1)

##Creating the block model
library(sna)
g2 <- as.matrix(get.adjacency(g1))
eq <- equiv.clust(g2)
plot(eq)

b <- blockmodel(g2,eq,k=3,mode="graphs")
plot(b)
