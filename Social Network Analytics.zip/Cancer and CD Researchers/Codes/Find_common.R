###Finding people common to 2015 and 2016
common <- intersect(rownames(florida.data),rownames(florida.data.16))

florida.data <- florida.data[rownames(florida.data) %in% common, ]
florida.data <- florida.data[,colnames(florida.data) %in% common ]
florida.data.16 <- florida.data.16[rownames(florida.data.16) %in% common, ]
florida.data.16 <- florida.data.16[,colnames(florida.data.16) %in% common ]