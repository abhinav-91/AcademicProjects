
###Finding people common to 2015 and 2016
common <- intersect(rownames(florida.data),rownames(florida.data.16))
common
florida.data <- florida.data[rownames(florida.data) %in% common, ]
florida.data <- florida.data[,colnames(florida.data) %in% common ]
florida.data.16 <- florida.data.16[rownames(florida.data.16) %in% common, ]
florida.data.16 <- florida.data.16[,colnames(florida.data.16) %in% common ]


florida.info.R <- florida.info.R[, colnames(florida.info.R) %in% common]
florida.info.R <- florida.info.R[rownames(florida.info.R) %in% common,]

florida.info.R.16 <- florida.info.R.16[, colnames(florida.info.R.16) %in% common]
florida.info.R.16 <- florida.info.R.16[rownames(florida.info.R.16) %in% common,]

florida.info.S.16 <- florida.info.S.16[, colnames(florida.info.S.16) %in% common]
florida.info.S.16 <- florida.info.S.16[rownames(florida.info.S.16) %in% common,]

florida.info.S <- florida.info.S[, colnames(florida.info.S) %in% common]
florida.info.S <- florida.info.S[rownames(florida.info.S) %in% common,]

attributes.data <- attributes.data[rownames(attributes.data) %in% common, ]

attributes.data.16 <- attributes.data[rownames(attributes.data.16) %in% common,]

