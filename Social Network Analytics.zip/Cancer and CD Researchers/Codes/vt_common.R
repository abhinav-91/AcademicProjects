
###Finding people common to 2015 and 2016
common <- intersect(rownames(vermont.data),rownames(vermont.data.16))
common
vermont.data <- vermont.data[rownames(vermont.data) %in% common, ]
vermont.data <- vermont.data[,colnames(vermont.data) %in% common ]
vermont.data.16 <- vermont.data.16[rownames(vermont.data.16) %in% common, ]
vermont.data.16 <- vermont.data.16[,colnames(vermont.data.16) %in% common ]


vermont.info.R <- vermont.info.R[, colnames(vermont.info.R) %in% common]
vermont.info.R <- vermont.info.R[rownames(vermont.info.R) %in% common,]

vermont.info.R.16 <- vermont.info.R.16[, colnames(vermont.info.R.16) %in% common]
vermont.info.R.16 <- vermont.info.R.16[rownames(vermont.info.R.16) %in% common,]

vermont.info.S.16 <- vermont.info.S.16[, colnames(vermont.info.S.16) %in% common]
vermont.info.S.16 <- vermont.info.S.16[rownames(vermont.info.S.16) %in% common,]

vermont.info.S <- vermont.info.S[, colnames(vermont.info.S) %in% common]
vermont.info.S <- vermont.info.S[rownames(vermont.info.S) %in% common,]

attributes.data <- attributes.data[rownames(attributes.data) %in% common, ]

attributes.data.16 <- attributes.data[rownames(attributes.data.16) %in% common,]

