##2015 data

#Reading the csv file
florida.data <- read.csv("Roundtables_SNA_2015_100716_FL how do you know.csv",header=TRUE)

#Converting the NA values into zero
florida.data[is.na(florida.data)] <- 0

#Convert the first column into rownames
rownames(florida.data) <- florida.data[,1]

#Drop the first column
florida.data <- florida.data[-c(1)]

#Convert anything greater than 1 into 1
florida.data[florida.data > 1] <- 1

###Reading the common
attributes.data <- read.csv("Roundtables_SNA_2015_101116_FL Attributes.csv")

rownames(attributes.data )<- attributes.data[,1]

###Reading the info file

florida.info.R <- read.csv("Roundtables_SNA_2015_100716_FL Receive info.csv",header=T)
florida.info.S <- read.csv("Roundtables_SNA_2015_100716_FL Send info.csv",header=T)


rownames(florida.info.R) <- florida.info.R[,1]
florida.info.R <- florida.info.R[,-1]
florida.info.R[florida.info.R > 1] <- 1
florida.info.R[is.na(florida.info.R)] <- 0

rownames(florida.info.S) <- florida.info.S[,1]
florida.info.S <- florida.info.S[,-1]
florida.info.S[florida.info.S > 1] <- 1
florida.info.S[is.na(florida.info.S)] <- 0


##2016 data

#Reading the csv file
florida.data.16 <- read.csv("Roundtables_SNA_2016_081916_FL how do you know.csv",header=TRUE)

#Converting the NA values into zero
florida.data.16[is.na(florida.data.16)] <- 0

#Convert the first column into rownames
rownames(florida.data.16) <- florida.data.16[,1]

#Drop the first column
florida.data.16 <- florida.data.16[-c(1)]

#Convert anything greater than 1 into 1
florida.data.16[florida.data.16 > 1] <- 1

###Reading the common
attributes.data.16 <- read.csv("Roundtables_SNA_2016_081916_FL Attributes.csv")

rownames(attributes.data.16 )<- attributes.data.16[,1]
###Reading the info file

florida.info.R.16 <- read.csv("Roundtables_SNA_2016_081916_FL Receive info.csv",header=T)
florida.info.S.16 <- read.csv("Roundtables_SNA_2016_081916_FL Send info.csv",header=T)


rownames(florida.info.R.16) <- florida.info.R.16[,1]
florida.info.R.16 <- florida.info.R.16[,-1]
florida.info.R.16[florida.info.R.16 > 1] <- 1
florida.info.R.16[is.na(florida.info.R.16)] <- 0

rownames(florida.info.S.16) <- florida.info.S.16[,1]
florida.info.S.16 <- florida.info.S.16[,-1]
florida.info.S.16[florida.info.S.16 > 1] <- 1
florida.info.S.16[is.na(florida.info.S.16)] <- 0


library(igraph)

#Creating the i-graph object and then plotting it
adj <- as.matrix(florida.data)

g1=graph.adjacency(adj,mode="directed",weighted=NULL,diag=FALSE)

plot(g1,margin=-0.4,edge.arrow.size=0.1)

adj <- as.matrix(florida.info.R)

g5=graph.adjacency(adj,mode="directed",weighted=NULL,diag=F)

adj <- as.matrix(florida.info.S)

g6=graph.adjacency(adj,mode="directed",weighted=NULL,diag=F)

edge_density(g1)

##Adding the attribute of C Researcher 
vertex_attr(g1)

rownames(attributes.data) <- attributes.data$PersonID

attributes.data <- attributes.data[,-1]

attributes.data[is.na(attributes.data)] <-0

attributes.data[attributes.data > 2] <- 0

att.data.c <- attributes.data$CancerCD

V(g1)$TopicC <- att.data.c
V(g5)$TopicC <- att.data.c
V(g6)$TopicC <- att.data.c


vertex.attributes(g1)

## Color coding the graph
V(g1)$color=V(g1)$TopicC
V(g5)$color=V(g5)$TopicC
V(g6)$color=V(g6)$TopicC
V(g1)$color=gsub(1,"red",V(g1)$color) #Cancer will be red
V(g1)$color=gsub(0,"blue",V(g1)$color) #Dont will be blue
V(g1)$color=gsub(2,"Yellow",V(g1)$color) #CD will be Yellow
plot.igraph(g1,margin=-0.3,edge.arrow.size=0.1)
title(main="Florida- 2015")
edge_density(g1)
V(g1)$TopicC
vertex.attributes(g1)
####Subgraph
florida <- subgraph(g1,V(g1)$TopicC =="1" | V(g1)$TopicC =="2")
plot(florida,edge.arrow.size=0.1,margin=-0.3)
title(main = "Cancer & CD Researcher")


florida.s <- subgraph(g5,V(g5)$TopicC == 1 | V(g5)$TopicC == 2)
plot(florida.s)
florida.r <- subgraph(g6,V(g5)$TopicC == 1 | V(g5)$TopicC == 2)


##Creating the block model
library(sna)
g1 <- as.matrix(get.adjacency(florida))
g7 <- as.matrix(get.adjacency(florida.s))
g8 <- as.matrix(get.adjacency(florida.r))

eq <- equiv.clust(list(g1,g7,g8))
plot(eq)


#######################################################################
#######################################################################
#######################################################################
#######################################################################



#Creating the i-graph object and then plotting it
adj <- as.matrix(florida.data.16)

g3=graph.adjacency(adj,mode="directed",weighted=NULL,diag=FALSE)

plot(g3,margin=-0.4,edge.arrow.size=0.1)

adj <- as.matrix(florida.info.R.16)

g5=graph.adjacency(adj,mode="directed",weighted=NULL,diag=F)

adj <- as.matrix(florida.info.S.16)

g6=graph.adjacency(adj,mode="directed",weighted=NULL,diag=F)


##Adding the attribute of C Researcher 
vertex_attr(g3)


rownames(attributes.data.16) <- attributes.data.16$PersonID

attributes.data.16 <- attributes.data.16[,-1]

attributes.data.16[is.na(attributes.data.16)] <-0

attributes.data.16[attributes.data.16 > 2] <- 0

att.data.c <- attributes.data.16$CancerCD

V(g3)$TopicC <- att.data.c
V(g5)$TopicC <- att.data.c
V(g6)$TopicC <- att.data.c

vertex.attributes(g3)
vertex.attributes(g3)
## Color coding the graph
V(g3)$color=V(g3)$TopicC
V(g5)$color=V(g5)$TopicC
V(g6)$color=V(g6)$TopicC
#V(g3)$color=gsub(1,"red",V(g1)$color) #Cancer will be red
#V(g3)$color=gsub(0,"blue",V(g1)$color) #Dont will be blue
#V(g3)$color=gsub(2,"Yellow",V(g1)$color) #CD will be Yellow
plot.igraph(g3,margin=-0.3,edge.arrow.size=0.1)
title(main="florida 2016")
edge_density(g3)

vertex.attributes(g3)
V(g3)$TopicC
####Subgraph
florida.16 <- subgraph(g3,V(g3)$TopicC == 1 | V(g3)$TopicC == 2)
plot(florida.16,edge.arrow.size=0.1,margin=-0.3)
title(main="Florida - Cancer & CD Researcher - 2016")

florida.16.s <- subgraph(g5,V(g5)$TopicC == 1 | V(g5)$TopicC == 2)
plot(florida.16.s)
florida.16.r <- subgraph(g6,V(g5)$TopicC == 1 | V(g5)$TopicC == 2)


##Creating the block model

library(sna)
g4 <- as.matrix(get.adjacency(florida.16))
g7 <- as.matrix(get.adjacency(florida.16.s))
g8 <- as.matrix(get.adjacency(florida.16.r))
eq <- equiv.clust(list(g4,g7,g8))
plot(eq)

b1 <- blockmodel(g4,eq,k=3,mode="graphs")
plot(b1)


