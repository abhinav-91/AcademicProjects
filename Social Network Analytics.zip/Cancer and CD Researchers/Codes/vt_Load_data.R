##2015 data

#Reading the csv file
vermont.data <- read.csv("Roundtables_SNA_2015_100716_VT How do you know.csv",header=TRUE)

#Converting the NA values into zero
vermont.data[is.na(vermont.data)] <- 0

#Convert the first column into rownames
rownames(vermont.data) <- vermont.data[,1]

#Drop the first column
vermont.data <- vermont.data[-c(1)]

#Convert anything greater than 1 into 1
vermont.data[vermont.data > 1] <- 1

###Reading the common
attributes.data <- read.csv("Roundtables_SNA_2015_101116_VT Attributes.csv")

rownames(attributes.data )<- attributes.data[,1]

###Reading the info file

vermont.info.R <- read.csv("Roundtables_SNA_2015_100716_VT Receive info.csv",header=T)
vermont.info.S <- read.csv("Roundtables_SNA_2015_100716_VT Send info.csv",header=T)


rownames(vermont.info.R) <- vermont.info.R[,1]
vermont.info.R <- vermont.info.R[,-1]
vermont.info.R[vermont.info.R > 1] <- 1
vermont.info.R[is.na(vermont.info.R)] <- 0

rownames(vermont.info.S) <- vermont.info.S[,1]
vermont.info.S <- vermont.info.S[,-1]
vermont.info.S[vermont.info.S > 1] <- 1
vermont.info.S[is.na(vermont.info.S)] <- 0


##2016 data

#Reading the csv file
vermont.data.16 <- read.csv("Roundtables_SNA_2016_081916_VT how do you know.csv",header=TRUE)

#Converting the NA values into zero
vermont.data.16[is.na(vermont.data.16)] <- 0

#Convert the first column into rownames
rownames(vermont.data.16) <- vermont.data.16[,1]

#Drop the first column
vermont.data.16 <- vermont.data.16[-c(1)]

#Convert anything greater than 1 into 1
vermont.data.16[vermont.data.16 > 1] <- 1

###Reading the common
attributes.data.16 <- read.csv("Roundtables_SNA_2016_081916_VT Attributes.csv")

rownames(attributes.data.16 )<- attributes.data.16[,1]
###Reading the info file

vermont.info.R.16 <- read.csv("Roundtables_SNA_2016_081916_VT Receive info.csv",header=T)
vermont.info.S.16 <- read.csv("Roundtables_SNA_2016_081916_VT Send info.csv",header=T)


rownames(vermont.info.R.16) <- vermont.info.R.16[,1]
vermont.info.R.16 <- vermont.info.R.16[,-1]
vermont.info.R.16[vermont.info.R.16 > 1] <- 1
vermont.info.R.16[is.na(vermont.info.R.16)] <- 0

rownames(vermont.info.S.16) <- vermont.info.S.16[,1]
vermont.info.S.16 <- vermont.info.S.16[,-1]
vermont.info.S.16[vermont.info.S.16 > 1] <- 1
vermont.info.S.16[is.na(vermont.info.S.16)] <- 0

